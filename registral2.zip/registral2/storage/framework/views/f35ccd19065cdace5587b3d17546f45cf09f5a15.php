<!DOCTYPE html>
<html lang="es" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<link rel="stylesheet" href=<?php echo e(asset('/css/app.css')); ?>>
		<link rel="stylesheet" href=<?php echo e(asset('/css/login.css')); ?>>
	</head>
	<body>
		<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
			</div>
		</div>
		<script src=<?php echo e(asset('/js/app.js')); ?>></script>
	</body>
</html>

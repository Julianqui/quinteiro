<?php $__env->startSection('title', 'Detalle del Producto'); ?>

<?php $__env->startSection('content'); ?>
	<?php if( session('alert') ): ?>
		<div class="alert alert-danger">
			<?php echo e(session('alert')); ?>

		</div>
	<?php endif; ?>
	<a href="/login"><button class="btn btn-primary" type="submit">Salir</button></a>
	<h2><?php echo e($product->name); ?></h2>
	<table class="table">
		<tr>
			<td>Price</td>
			<td>Image</td>
			<td>Colors</td>
			<td>Category</td>
			<td>Brand</td>
		</tr>
		<tr>
			<td><b>$</b><?php echo e($product->price); ?></td>
			<td><img src="<?php echo e(Storage::url('products/' . $product->image)); ?>" width="100"></td>
			<td>
				<ul>
				<?php $__empty_1 = true; $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<li><?php echo e($color->name); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<li>Sin colores relacionados</li>
				<?php endif; ?>
				</ul>
			</td>
			<td><?php echo e($product->category->name ?? 'No tiene categoría'); ?></td>
			<td><?php echo e($product->brand->name ?? 'No tiene marca'); ?></td>
		</tr>
	</table>

	<?php if(auth()->guard()->check()): ?>
		<?php if($product->user_id == Auth::user()->id ): ?>
			<a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning">Edit</a>

			<form action="/products/<?php echo e($product->id); ?>" method="post" style="display: inline-block;">
				<?php echo csrf_field(); ?>
				<?php echo e(method_field('DELETE')); ?>

				<button id="delete" type="submit" class="btn btn-danger">Delete</button>
			</form>
		<?php endif; ?>
	<?php endif; ?>


	<script>
		let btn = document.querySelector('#delete');
		btn.addEventListener('click', function () {
			window.alert('¿Seguro querés borrar el producto <?php echo e($product->name); ?>?');
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
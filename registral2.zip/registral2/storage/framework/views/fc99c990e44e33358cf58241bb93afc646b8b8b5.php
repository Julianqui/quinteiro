<?php $__env->startSection('title', 'Tu profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Buen dia <?php echo e(Auth::user()->name); ?></h2>

    <form action="/login" method="post">
      <?php echo csrf_field(); ?>
      <button class="btn btn-outline-primary" type="submit">Salir</button>
	  <!-- <button class="btn btn-success" type="submit">Salir</button>
	  <button class="btn btn-success" type="submit">Salir</button> -->
    </form>
    <br>
    <br>
    <h2>Seleccione al usuario</h2>
    <table class="table">
  		<tr>
  			<td>Nombre</td>
  			<!-- <td>Price</td>
  			<td>Image</td>
  			<td>Colors</td>
  			<td>Category</td>
  			<td>Brand</td> -->
  		</tr>
  		<?php $__empty_1 = true; $__currentLoopData = Auth::user()->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  			<tr>
  				<td>
				  <button class="btn btn-outline-dark btn-lg" type="submit">
				  		<p>
  					<a href="<?php echo e(route('products.show', $oneProduct->id)); ?>">
  						<?php echo e($oneProduct->name); ?>

  					</a>
					  </p>  
				  </button> 	  
  				</td>
  				<!-- <td><b>$</b><?php echo e($oneProduct->price); ?></td>
  				<td><img src="<?php echo e(Storage::url('products/' . $oneProduct->image)); ?>" width="100"></td>
  				<td>
  					<ul>
  					<?php $__empty_2 = true; $__currentLoopData = $oneProduct->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
  						<li><?php echo e($color->name); ?></li>
  					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
  						<li>Sin colores relaciondos</li>
  					<?php endif; ?>
  					</ul>
  				</td>
  				<td><?php echo e($oneProduct->category->name ?? 'No tiene categoría'); ?></td>
  				<td><?php echo e($oneProduct->brand->name ?? 'No tiene marca'); ?></td> -->
  			</tr>
  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

  		<?php endif; ?>
  	</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Crear un producto'); ?>

<?php $__env->startSection('content'); ?>
	<br>
	

	<form action="/products" method="post" enctype="multipart/form-data">
	
		<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col-6">
				<div class="form-group">
					<label for="name">Name:</label>
					<input type="text" name="name" id="name"
						class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : null); ?>"
						value="<?php echo e(old('name')); ?>"
					>
					<span class="invalid-feedback">
						<?php if($errors->has('name')): ?>
							<?php echo e($errors->first('name')); ?>

						<?php endif; ?>
					</span>
				</div>
			</div>
			<div class="col-6">
				<div class="form-group">
					<label for="price">Price:</label>
					<input type="text" name="price" id="price"
						class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : null); ?>"
						value="<?php echo e(old('price')); ?>"
					>
					<span class="invalid-feedback">
						<?php echo e($errors->has('price') ? $errors->first('price') : null); ?>

					</span>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-6">
				<div class="form-group">
					<label for="brand_id">Brand:</label>
					<select name="brand_id"  id="brand_id"
						class="form-control <?php echo e($errors->has('brand_id') ? 'is-invalid' : null); ?>"
					>
						<option value="">Seleccioná</option>
						<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($oneBrand->id); ?>"
								<?php echo e(old('brand_id') == $oneBrand->id ? 'selected' : null); ?>

							>
								<?php echo e($oneBrand->name); ?>

							</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<span class="invalid-feedback">
						<?php echo e($errors->has('brand_id') ? $errors->first('brand_id') : null); ?>

					</span>
				</div>
			</div>
			<div class="col-6">
				<div class="form-group">
					<label for="category_id">Category:</label>
					<select name="category_id" id="category_id"
						class="form-control <?php echo e($errors->has('category_id') ? 'is-invalid' : null); ?>"
					>
						<option value="">Seleccioná</option>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($oneCategory->id); ?>"
								<?php echo e(old('category_id') == $oneCategory->id ? 'selected' : null); ?>

							>
								<?php echo e($oneCategory->name); ?>

							</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<span class="invalid-feedback">
						<?php echo e($errors->has('category_id') ? $errors->first('category_id') : null); ?>

					</span>
				</div>
			</div>

			<div class="col-6">
				<div class="form-group">
					<label for="category_id">Subí una imagen:</label>
					<div class="custom-file">
					   <input type="file"  id="image" name="image"
							class="custom-file-input <?php echo e($errors->has('image') ? 'is-invalid' : null); ?>"
						>
					   <label class="custom-file-label" for="image">Elegí una imagen</label>

						<span class="invalid-feedback">
							<?php echo e($errors->has('image') ? $errors->first('image') : null); ?>

						</span>
					 </div>
				</div>
			</div>
		</div>

		<button type="submit" class="btn btn-success">Save product</button>
	</form>

	<script>
		let campoName = document.querySelector('#name');
		campoName.addEventListener('blur', function () {
			if (this.value.trim() === '') {
				this.classList.add('is-invalid');
				this.parentElement.querySelector('span').innerText = 'Campo obligatorio';
			} else {
				this.classList.remove('is-invalid');
				this.parentElement.querySelector('span').innerText = '';
			}
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>